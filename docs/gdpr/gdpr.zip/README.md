# Your Data
DiscordMailHooks stores no end user data.

To terminate your subscription to DiscordMailHooks, simply delete the webhook within Discord.
